var mobilepurchase = artifacts.require("./mobilepurchase.sol");
module.exports = function(deployer) {
  deployer.deploy(mobilepurchase);
};
